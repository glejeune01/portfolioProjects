window.onload = function () {
  document.querySelector("#AddButton").addEventListener("click", addExercise);
  document.querySelector("#DeleteButton").addEventListener("click", deleteExercise);
  document.querySelector("#UpdateButton").addEventListener("click", updateExercise);
  document.querySelector("#DoneButton").addEventListener("click", processForm);
  document.querySelector("#CancelButton").addEventListener("click", hideUpdatePanel);
  document.querySelector("#LoadButton").addEventListener("click", getAllExercises);
  document.querySelector("#exerciseLogTable").addEventListener("click", handleRowClick);

  hideUpdatePanel();
};


function getAllExercises() {
  let url = "api/getAllExercises.php";
  let xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        let resp = xhr.responseText;
        console.log(resp);
        if (resp.search("ERROR") >= 0) {
          alert("Oh no, something is wrong with the GET...");
        } else {
          buildTable(xhr.responseText);
          setDeleteUpdateButtonState(false);
        }
      } else {
        alert("Received status code " + xhr.status);
      }
    }
  };
  xhr.open("GET", url, true);
  xhr.send();
}

function buildTable(text) {
  let arr = JSON.parse(text);
  let html =
    "<table><tr><th>Activity ID</th><th>Activity Name</th><th>Category</th><th>Duration (minutes)</th><th>Calories Burned</th></tr>";
  for (let i = 0; i < arr.length; i++) {
    let row = arr[i];
    html += "<tr>";
    html += "<td>" + row.activityId + "</td>";
    html += "<td>" + row.activityName + "</td>";
    html += "<td>" + row.activityCategory + "</td>";
    html += "<td>" + row.durationMinutes + "</td>";
    html += "<td>" + row.caloriesBurned + "</td>";
    html += "</tr>";
  }
  html += "</table>";
  let theTable = document.querySelector("#exerciseLogTable");
  theTable.innerHTML = html;
}

function addExercise() {
  addOrUpdate = "add";
  clearUpdatePanel();
  showUpdatePanel();
}

function updateExercise() {
  addOrUpdate = "update";
  populateUpdatePanel();
  showUpdatePanel();
}

function deleteExercise() {
  let row = document.querySelector(".selected");
  let id = Number(row.querySelectorAll("td")[0].innerHTML);

  let url = "api/deleteExercise.php?activityId=" + id;
  let xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      let resp = xhr.responseText;
      if (resp === "1") {
        alert("Exercise deleted.");
      } else if (resp === "0") {
        alert("Exercise was not deleted.");
      } else {
        alert("Server Error!");
      }
      getAllExercises();
    }
  };
  xhr.open("GET", url, true);
  xhr.send();
}

function processForm() {
  console.log("OK");

  let activityName = document.querySelector("#activityName").value;
  let activityCategory = document.querySelector("#activityCategory").value;
  let durationMinutes = Number(document.querySelector("#durationMinutes").value);
  let caloriesBurned = Number(document.querySelector("#caloriesBurned").value);

  let obj = {
    activityName: activityName,
    activityCategory: activityCategory,
    durationMinutes: durationMinutes,
    caloriesBurned: caloriesBurned,
  };

  if (addOrUpdate === "update") {
    let activityId = Number(document.querySelector("#activityId").value);
    obj.activityId = activityId;
  }

  let url = addOrUpdate === "add" ? "api/addExercise.php" : "api/updateExercise.php";
  let xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      let resp = xhr.responseText;
      console.log(resp, resp.length);
      if (resp === "1") {
        alert("Exercise " + (addOrUpdate === "add" ? "added." : "updated."));
      } else if (resp === "0") {
        alert("Exercise NOT " + (addOrUpdate === "add" ? "added." : "updated."));
      } else {
        alert("Server Error!");
      }
      hideUpdatePanel();
      getAllExercises();
    }
  };
  xhr.open("POST", url, true);
  xhr.send(JSON.stringify(obj));
}

function hideUpdatePanel() {
  document.querySelector("#AddUpdatePanel").classList.add("hidden");
}

function showUpdatePanel() {
  document.querySelector("#AddUpdatePanel").classList.remove("hidden");
}

function clearUpdatePanel() {
  document.querySelector("#activityName").value = "";
  document.querySelector("#activityCategory").value = "";
  document.querySelector("#durationMinutes").value = "";
  document.querySelector("#caloriesBurned").value = "";
}

function populateUpdatePanel() {
  let selectedItem = document.querySelector(".selected");
  let activityId = Number(selectedItem.querySelector("td:nth-child(1)").innerHTML);
  let activityName = selectedItem.querySelector("td:nth-child(2)").innerHTML;
  let activityCategory = selectedItem.querySelector("td:nth-child(3)").innerHTML;
  let durationMinutes = Number(selectedItem.querySelector("td:nth-child(4)").innerHTML);
  let caloriesBurned = Number(selectedItem.querySelector("td:nth-child(5)").innerHTML);

  document.querySelector("#activityId").value = activityId;
  document.querySelector("#activityName").value = activityName;
  document.querySelector("#activityCategory").value = activityCategory;
  document.querySelector("#durationMinutes").value = durationMinutes;
  document.querySelector("#caloriesBurned").value = caloriesBurned;
}

function setDeleteUpdateButtonState(state) {
  if (state) {
    document.querySelector("#DeleteButton").removeAttribute("disabled");
    document.querySelector("#UpdateButton").removeAttribute("disabled");
  } else {
    document.querySelector("#DeleteButton").setAttribute("disabled", "disabled");
    document.querySelector("#UpdateButton").setAttribute("disabled", "disabled");
  }
}

function handleRowClick(evt) {
  clearSelections();
  evt.target.parentElement.classList.add("selected");
  setDeleteUpdateButtonState(true);
}

function clearSelections() {
  let trs = document.querySelectorAll("tr");
  for (let i = 0; i < trs.length; i++) {
    trs[i].classList.remove("selected");
  }
}
