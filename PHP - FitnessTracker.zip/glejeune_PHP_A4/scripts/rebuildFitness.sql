CREATE DATABASE IF NOT EXISTS fitness_tracker;

USE fitness_tracker;

CREATE TABLE IF NOT EXISTS exercise_log (
    activity_id INT AUTO_INCREMENT PRIMARY KEY,
    activity_name VARCHAR(255) NOT NULL,
    activity_category VARCHAR(255) NOT NULL,
    duration_minutes INT,
    calories_burned INT
);

INSERT INTO exercise_log (activity_name, activity_category, duration_minutes, calories_burned) VALUES
    ('Underwater Basket Weaving', 'Unique', 90, 400),
    ('Extreme Hula Hooping', 'Unconventional', 60, 300),
    ('Parkour Tag', 'Adventurous', 45, 150),
    ('Urban Axe Throwing', 'Unusual', 30, 500),
    ('Sandcastle Sculpting', 'Artistic', 180, 400),
    ('Unicycle Juggling', 'Circus Arts', 45, 200),
    ('Slackline Yoga', 'Balance', 60, 550),
    ('Bungee Trampolining', 'Thrilling', 60, 250),
    ('Indoor Skydiving', 'Aerial', 120, 350),
    ('Disco Roller Derby', 'Retro', 90, 800),
    ('Medieval Sword Fighting', 'Historical', 60, 400),
    ('Extreme Frisbee Golf', 'Disc Sports', 45, 350),
    ('Trampoline Dodgeball', 'High Energy', 60, 500),
    ('Quidditch', 'Fantasy', 90, 600),
    ('Extreme Snowshoeing', 'Winter Sport', 120, 700),
    ('Steampunk Steeplechase', 'Alternative', 45, 300),
    ('Fire Dancing', 'Cultural', 60, 350),
    ('Volcano Boarding', 'Adventure Sport', 90, 600);
