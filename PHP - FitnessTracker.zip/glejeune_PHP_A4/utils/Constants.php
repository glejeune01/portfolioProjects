<?php
class Constants
{
    public static $MYSQL_CONNECTION_STRING = "mysql:host=localhost;dbname=fitness_tracker";
    public static $MYSQL_USERNAME = "root";
    public static $MYSQL_PASSWORD = "!Tornucks1";
}
