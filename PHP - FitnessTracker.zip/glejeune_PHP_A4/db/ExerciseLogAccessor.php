<?php
require_once dirname(__DIR__, 1) . '/entity/ExerciseLog.php';

class ExerciseLogAccessor
{
    private $getAllStatementString = "SELECT * FROM exercise_log";
    private $getByIDStatementString = "SELECT * FROM exercise_log WHERE activity_id = :activity_id";
    private $deleteStatementString = "DELETE FROM exercise_log WHERE activity_id = :activity_id";
    private $insertStatementString = "INSERT INTO exercise_log (activity_name, activity_category, duration_minutes, calories_burned) VALUES (:activity_name, :activity_category, :duration_minutes, :calories_burned)";
    private $updateStatementString = "UPDATE exercise_log SET activity_name = :activity_name, activity_category = :activity_category, duration_minutes = :duration_minutes, calories_burned = :calories_burned WHERE activity_id = :activity_id";

    private $getAllStatement = null;
    private $getByIDStatement = null;
    private $deleteStatement = null;
    private $insertStatement = null;
    private $updateStatement = null;

    public function __construct($conn)
    {
        if (is_null($conn)) {
            throw new Exception("No connection");
        }

        $this->getAllStatement = $conn->prepare($this->getAllStatementString);
        if (is_null($this->getAllStatement)) {
            throw new Exception("Bad statement: '" . $this->getAllStatementString . "'");
        }

        $this->getByIDStatement = $conn->prepare($this->getByIDStatementString);
        if (is_null($this->getByIDStatement)) {
            throw new Exception("Bad statement: '" . $this->getByIDStatementString . "'");
        }

        $this->deleteStatement = $conn->prepare($this->deleteStatementString);
        if (is_null($this->deleteStatement)) {
            throw new Exception("Bad statement: '" . $this->deleteStatementString . "'");
        }

        $this->insertStatement = $conn->prepare($this->insertStatementString);
        if (is_null($this->insertStatement)) {
            throw new Exception("Bad statement: '" . $this->insertStatementString . "'");
        }

        $this->updateStatement = $conn->prepare($this->updateStatementString);
        if (is_null($this->updateStatement)) {
            throw new Exception("Bad statement: '" . $this->updateStatementString . "'");
        }
    }

    public function getAllExerciseLogs()
    {
        $results = [];

        try {
            $this->getAllStatement->execute();
            $dbresults = $this->getAllStatement->fetchAll(PDO::FETCH_ASSOC);

            foreach ($dbresults as $r) {
                $activityId = $r['activity_id'];
                $activityName = $r['activity_name'];
                $activityCategory = $r['activity_category'];
                $durationMinutes = $r['duration_minutes'];
                $caloriesBurned = $r['calories_burned'];
                $obj = new ExerciseLog($activityId, $activityName, $activityCategory, $durationMinutes, $caloriesBurned);
                array_push($results, $obj);
            }
        } catch (Exception $e) {
            $results = [];
        } finally {
            if (!is_null($this->getAllStatement)) {
                $this->getAllStatement->closeCursor();
            }
        }

        return $results;
    }

    private function getExerciseLogByID($activityId)
    {
        $result = null;

        try {
            $this->getByIDStatement->bindParam(":activity_id", $activityId);
            $this->getByIDStatement->execute();
            $dbresults = $this->getByIDStatement->fetch(PDO::FETCH_ASSOC);

            if ($dbresults) {
                $activityId = $dbresults['activity_id'];
                $activityName = $dbresults['activity_name'];
                $activityCategory = $dbresults['activity_category'];
                $durationMinutes = $dbresults['duration_minutes'];
                $caloriesBurned = $dbresults['calories_burned'];
                $result = new ExerciseLog($activityId, $activityName, $activityCategory, $durationMinutes, $caloriesBurned);
            }
        } catch (Exception $e) {
            $result = null;
        } finally {
            if (!is_null($this->getByIDStatement)) {
                $this->getByIDStatement->closeCursor();
            }
        }

        return $result;
    }

    public function exerciseLogExists($exerciseLog)
    {
        return $this->getExerciseLogByID($exerciseLog->getActivityId()) !== null;
    }

    public function deleteExerciseLog($exerciseLog)
    {
        if (!$this->exerciseLogExists($exerciseLog)) {
            return false;
        }

        $success = false;
        $activityId = $exerciseLog->getActivityId();

        try {
            $this->deleteStatement->bindParam(":activity_id", $activityId);
            $success = $this->deleteStatement->execute();
            $success = $success && $this->deleteStatement->rowCount() === 1;
        } catch (PDOException $e) {
            $success = false;
        } finally {
            if (!is_null($this->deleteStatement)) {
                $this->deleteStatement->closeCursor();
            }
        }

        return $success;
    }

    public function insertExerciseLog($exerciseLog)
    {
        $success = false;

        $activityName = $exerciseLog->getActivityName();
        $activityCategory = $exerciseLog->getActivityCategory();
        $durationMinutes = $exerciseLog->getDurationMinutes();
        $caloriesBurned = $exerciseLog->getCaloriesBurned();

        try {
            $this->insertStatement->bindParam(":activity_name", $activityName);
            $this->insertStatement->bindParam(":activity_category", $activityCategory);
            $this->insertStatement->bindParam(":duration_minutes", $durationMinutes);
            $this->insertStatement->bindParam(":calories_burned", $caloriesBurned);
            $success = $this->insertStatement->execute();
            $success = $this->insertStatement->rowCount() === 1;
        } catch (PDOException $e) {
            $success = false;
        } finally {
            if (!is_null($this->insertStatement)) {
                $this->insertStatement->closeCursor();
            }
        }

        return $success;
    }

    public function updateExerciseLog($exerciseLog)
    {
        if (!$this->exerciseLogExists($exerciseLog)) {
            return false;
        }

        $success = false;
        $activityId = $exerciseLog->getActivityId();
        $activityName = $exerciseLog->getActivityName();
        $activityCategory = $exerciseLog->getActivityCategory();
        $durationMinutes = $exerciseLog->getDurationMinutes();
        $caloriesBurned = $exerciseLog->getCaloriesBurned();

        try {
            $this->updateStatement->bindParam(":activity_id", $activityId);
            $this->updateStatement->bindParam(":activity_name", $activityName);
            $this->updateStatement->bindParam(":activity_category", $activityCategory);
            $this->updateStatement->bindParam(":duration_minutes", $durationMinutes);
            $this->updateStatement->bindParam(":calories_burned", $caloriesBurned);
            $success = $this->updateStatement->execute();
            $success = $this->updateStatement->rowCount() === 1;
        } catch (PDOException $e) {
            $success = false;
        } finally {
            if (!is_null($this->updateStatement)) {
                $this->updateStatement->closeCursor();
            }
        }

        return $success;
    }
}
