<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Fitness Tracker</title>

    <link rel="stylesheet" href="styles.css">
    <script src="main.js"></script>
    
</head>

<body>
    <div id="content" class="container">
        <h1>Fitness Tracker</h1>

        <button id="LoadButton" class="btn-primary">Load exercises</button>
        <div id="ButtonPanel">
            <button id="AddButton" class="btn-primary">Add</button>
            <button id="DeleteButton" class="btn-primary" disabled>
                Delete
            </button>
            <button id="UpdateButton" class="btn-primary" disabled>
                Update
            </button>
        </div>

        <div id="AddUpdatePanel" class="hidden">
            <input type="hidden" id="activityId" name="activityId" value="">
            <div class="inputContainer">
                <div class="inputLabel">Activity Name:</div>
                <div class="inputField">
                    <input id="activityName" name="activityName" />
                </div>
            </div>
            <div class="inputContainer">
                <div class="inputLabel">Category:</div>
                <div class="inputField">
                    <input id="activityCategory" name="activityCategory"/>
                </div>
            </div>
            <div class="inputContainer">
                <div class="inputLabel">Duration (minutes):</div>
                <div class="inputField">
                    <input id="durationMinutes" type="number" name="durationMinutes" min="0"/>
                </div>
            </div>
            <div class="inputContainer">
                <div class="inputLabel">Calories Burned:</div>
                <div class="inputField">
                    <input id="caloriesBurned" type="number" name="caloriesBurned" min="0"/>
                </div>
            </div>
            <div class="inputContainer">
                <div class="inputLabel">&nbsp;</div>
                <div class="inputField">
                    <button id="DoneButton" class="btn-primary">
                        Done
                    </button>
                    <button id="CancelButton" class="btn-primary">
                        Cancel
                    </button>
                </div>
            </div>
        </div>

        <div id="exerciseLogTable">
            <!-- to be filled in by JS -->
        </div>
    </div>
    <script src="main.js"></script>
</body>

</html>
