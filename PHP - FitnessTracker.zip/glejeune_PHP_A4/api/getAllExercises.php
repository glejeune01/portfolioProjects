<?php
require_once dirname(__DIR__, 1) . '/db/ConnectionManager.php';
require_once dirname(__DIR__, 1) . '/db/ExerciseLogAccessor.php'; 
require_once dirname(__DIR__, 1) . '/entity/ExerciseLog.php'; 
require_once dirname(__DIR__, 1) . '/utils/Constants.php';

try {
    $cm = new ConnectionManager(Constants::$MYSQL_CONNECTION_STRING, Constants::$MYSQL_USERNAME, Constants::$MYSQL_PASSWORD);
    $ela = new ExerciseLogAccessor($cm->getConnection()); 
    $results = $ela->getAllExerciseLogs(); 
    $results = json_encode($results, JSON_NUMERIC_CHECK);
    echo $results;
} catch (Exception $e) {
    echo "ERROR " . $e->getMessage();
}

