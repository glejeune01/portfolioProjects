<?php
require_once dirname(__DIR__, 1) . '/db/ConnectionManager.php';
require_once dirname(__DIR__, 1) . '/db/ExerciseLogAccessor.php';
require_once dirname(__DIR__, 1) . '/entity/ExerciseLog.php';
require_once dirname(__DIR__, 1) . '/utils/Constants.php';

$body = file_get_contents('php://input');
$contents = json_decode($body, true);

$activityId = $contents['activityId'];
$activityName = $contents['activityName'];
$activityCategory = $contents['activityCategory'];
$durationMinutes = $contents['durationMinutes'];
$caloriesBurned = $contents['caloriesBurned'];

$exerciseLogObject = new ExerciseLog($activityId, $activityName, $activityCategory, $durationMinutes, $caloriesBurned);

try {
    $cm = new ConnectionManager(Constants::$MYSQL_CONNECTION_STRING, Constants::$MYSQL_USERNAME, Constants::$MYSQL_PASSWORD);
    $ela = new ExerciseLogAccessor($cm->getConnection());
    $success = $ela->updateExerciseLog($exerciseLogObject);
    echo $success ? 1 : 0;
} catch (Exception $e) {
    echo "ERROR " . $e->getMessage();
}
