<?php
require_once dirname(__DIR__, 1) . '/db/ConnectionManager.php';
require_once dirname(__DIR__, 1) . '/db/ExerciseLogAccessor.php';
require_once dirname(__DIR__, 1) . '/entity/ExerciseLog.php';
require_once dirname(__DIR__, 1) . '/utils/Constants.php';

// Passed as a URL parameter
$activityId = intval($_GET['activityId']);

// Create a dummy ExerciseLog object with only the ID
$exerciseLogObj = new ExerciseLog($activityId, "dummyActivityName", "dummyCategory", 0, 0);

// Delete from the DB
try {
    $cm = new ConnectionManager(Constants::$MYSQL_CONNECTION_STRING, Constants::$MYSQL_USERNAME, Constants::$MYSQL_PASSWORD);
    $ela = new ExerciseLogAccessor($cm->getConnection());
    $success = $ela->deleteExerciseLog($exerciseLogObj);
    echo $success ? 1 : 0;
} catch (Exception $e) {
    echo "ERROR " . $e->getMessage();
}
