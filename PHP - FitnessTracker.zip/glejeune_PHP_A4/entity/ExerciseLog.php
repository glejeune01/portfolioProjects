<?php
class ExerciseLog implements JsonSerializable
{
    private $activityId;
    private $activityName;
    private $activityCategory;
    private $durationMinutes;
    private $caloriesBurned;

    public function __construct($activityId, $activityName, $activityCategory, $durationMinutes, $caloriesBurned)
    {
        $this->activityId = $activityId;
        $this->activityName = $activityName;
        $this->activityCategory = $activityCategory;
        $this->durationMinutes = $durationMinutes;
        $this->caloriesBurned = $caloriesBurned;
    }

    public function getActivityId()
    {
        return $this->activityId;
    }

    public function getActivityName()
    {
        return $this->activityName;
    }

    public function getActivityCategory()
    {
        return $this->activityCategory;
    }

    public function getDurationMinutes()
    {
        return $this->durationMinutes;
    }

    public function getCaloriesBurned()
    {
        return $this->caloriesBurned;
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}