package glejeunea2;

/**
 * Class to represent a book
 */
public class Books {

    private String author;
    private String title;
    private String[] formats;
    private double[] prices;

    //constructor for 2 parameters
    public Books(String aAuthor, String aTitle) {
        author = aAuthor;
        title = aTitle;
        formats = null;
        prices = null;
    }

    //constructor for 4 parameters
    public Books(String aAuthor, String aTitle, String[] aFormats, double[] aPrices) {
        author = aAuthor;
        title = aTitle;
        formats = aFormats;
        prices = aPrices;
    }

    //checking if book is for sale
    public boolean isForSale() {
        return prices != null;
    }

    //check if a book has a format
public boolean isAvailableInFormat(String formatSelector) {
    if (formatSelector == null || formats == null) {
        return false; 
    }

    for (String format : formats) {
        if (format.equalsIgnoreCase(formatSelector)) {
            return true;
        }
    }
    return false;
}

    
    //Overriding the toString method, and 
    @Override
    public String toString() {
        String result = author + ", " + title;

        if (isForSale()) {
            for (int i = 0; i < formats.length; i++) {
                result += ", " + formats[i] + " = " + prices[i];
            }
        } else {
            result += " (Not for Sale)";
        }

        return result;
    }
}
