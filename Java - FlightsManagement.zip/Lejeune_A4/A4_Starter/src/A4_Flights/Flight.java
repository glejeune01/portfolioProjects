package A4_Flights;

/**
 * Flight - a nonstop flight departing from the home airport Flight is the parent class for Training, Cargo, and Passenger Flights
 */
public abstract class Flight implements PolicyRules {

    // TODO-A1 - Complete this class, using javadocs as a reference
    private String dayOfWeek;
    private int departureTime;
    private Location destination;
    private String flightNumber;
    private int numCrew;

    public Flight(String flightNumber, String dayOfWeek, int departureTime, Location destination, int numCrew) {
        this.flightNumber = flightNumber;
        this.dayOfWeek = dayOfWeek;
        this.departureTime = departureTime;
        this.destination = destination;
        this.numCrew = numCrew;
    }

    public int calculateWeight() {
        return Common.AVERAGE_PERSON_WEIGHT * numCrew;
    }

    public String toDisplayReport() {
        String formattedDisplay
                = getFlightType() + " Flight = " + flightNumber + ", Day = " + dayOfWeek + ", Time = " + departureTime
                + "\n\tDestination: " + destination.toDisplayFormat()
                + "\n\tNumber of Crew: " + numCrew
                + "\n\tTotal Weight: " + Common.format(calculateWeight());

        return formattedDisplay;
    }

    public String toArchiveFormat() {
        String formattedArchive = getFlightType() + "," + flightNumber + "," + dayOfWeek + "," + departureTime + "," + destination.getLocationCode() + "," + numCrew + ",";
        return formattedArchive;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public int getDepartureTime() {
        return departureTime;
    }

    public Location getDestination() {
        return destination;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public int getNumCrew() {
        return numCrew;
    }

    public abstract String getFlightType();

    @Override
    public boolean checkCrew() {
        return numCrew > Common.MINIMUM_CREW;
    }

    @Override
    public abstract boolean checkTime();

    @Override
    public boolean checkWeight() {
        return calculateWeight() < Common.MAXIMUM_WEIGHT;
    }

    @Override
    public boolean checkPassengers() {
        return true;
    }

} // end class Flight
