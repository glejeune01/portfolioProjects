package A4_Flights;

/**
 * A passenger flight has no cargo
 */
public class PassengerFlight extends Flight {

    // TODO-A3 - Complete this class, using javadocs as a reference
    private int numPassengers;

    public PassengerFlight(String flightNumber, String dayOfWeek, int departureTime, Location destination, int numCrew, int numPassengers) {
        super(flightNumber, dayOfWeek, departureTime, destination, numCrew);
        this.numPassengers = numPassengers;
    }

    @Override
    public String getFlightType() {
        return "Passenger";
    }

    @Override
    public int calculateWeight() {
        int totalWeight = Common.AVERAGE_PERSON_WEIGHT * numPassengers + (super.calculateWeight());
        return totalWeight;
    }

    public int getNumPassengers() {
        return numPassengers;
    }

    @Override
    public String toArchiveFormat() {
        return super.toArchiveFormat() + numPassengers;
    }

    @Override
    public String toDisplayReport() {
        String oldString = super.toDisplayReport();
        String newString = oldString.replaceFirst("Total Weight: ", "Passengers: " + numPassengers + "\n\tTotal Weight: ");
        return newString;
    }

    @Override
    public boolean checkPassengers() {
        return numPassengers > Common.MINIMUM_PASSENGERS;
    }

    @Override
    public boolean checkTime() {
        return true;
    }

} // end class PassengerFlight
