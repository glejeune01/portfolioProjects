package A4_Flights;

import java.util.ArrayList;

public class FlightSchedule {

    private final Flight[] flights;

    /**
     * Creates a new schedule based on the specified flights.
     *
     * @param flights the flights to be contained in this schedule
     */
    public FlightSchedule(Flight[] flights) {
        this.flights = flights;
    }

    /**
     * Gets all of the flights in this schedule.
     *
     * @return all of the flights in this schedule
     */
    public Flight[] getAllFlights() {
        return flights;
    }

    public Flight[] getFlightsByDestination(String locationCode) {
        // TODO-B1
        ArrayList<Flight> destinationFlights = new ArrayList<>();
        for (Flight flight : flights) {
            Location destination = flight.getDestination();
            String code = destination.getLocationCode();
            if (code.equals(locationCode)) {
                destinationFlights.add(flight);
            }
        }
        return destinationFlights.toArray(new Flight[0]);
        
    }

    public int countFlightsByDestination(String locationCode) {
        // TODO-B1
        int flightCount = 0;
        for (Flight flight : flights) {
            Location destination = flight.getDestination();
            String code = destination.getLocationCode();
            if(code.equals(locationCode))
            {
                flightCount++;
            }
        }
        
        return flightCount;
    }

    public Flight[] getFlightsByType(String flightType) {
        // TODO-B2
        ArrayList<Flight> typeFlights = new ArrayList<>();
        for (Flight flight : flights) {

            if (flight.getFlightType().equals(flightType)) {
                typeFlights.add(flight);
            }
        }
        return typeFlights.toArray(new Flight[0]);
    }

    public int countFlightsByType(String flightType) {
        // TODO-B2
        int flightByType = 0;
        
        for (Flight flight : flights) {
            if (flight.getFlightType().equals(flightType)) {
                flightByType++;
            }
        }
        
        return flightByType;
    }
    

} // end class FlightSchedule
