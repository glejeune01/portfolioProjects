package A4_Flights;

/**
 * Cargo inherits from Flight Cargo flights have crew, cargo, but no passengers
 */
public class CargoFlight extends Flight {

    // TODO-A2 - Complete this class, using javadocs as a reference
    private int cargoWeight;

    public CargoFlight(int cargoWeight, String flightNumber, String dayOfWeek, int departureTime, Location destination, int numCrew) {
        super(flightNumber, dayOfWeek, departureTime, destination, numCrew);
        this.cargoWeight = cargoWeight;
    }

    @Override
    public String getFlightType() {
        return "Cargo";
    }

    @Override
    public int calculateWeight() {
        int totalWeight = cargoWeight + (super.calculateWeight());
        return totalWeight;
    }

    public double getCargoWeight() {
        return cargoWeight;
    }

    @Override
    public String toArchiveFormat() {
        String formattedString = super.toArchiveFormat() + cargoWeight;
        return formattedString;
    }

    @Override
    public String toDisplayReport() {
        String oldString = super.toDisplayReport();
        String newString = oldString.replaceFirst("Total Weight: ", "Cargo Weight: " + Common.format(getCargoWeight()) + "\n\tTotal Weight: ");
        return newString;
    }

    @Override
    public boolean checkTime() {
        return true;
    }

} // end class CargoFlight
