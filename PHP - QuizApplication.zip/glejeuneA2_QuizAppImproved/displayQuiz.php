<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>Quiz Display</title>
</head>

<body>
    <?php
    include 'ChromePhp.php';
    include 'FileUtils.php';
    session_start();

    //If I've got data set and I've selected a quiz - populating the quiz data
    if (isset($_SESSION['myData']) && isset($_SESSION['selectedQuiz'])) {
        $quiz = $_SESSION['myData'];

        //Setting my current question and submitted answers to 0/empty unless I've already got one set
        $currentQuestion = isset($_SESSION['currentQuestion']) ? $_SESSION['currentQuestion'] : 0;
        $submitAns = isset($_SESSION['submitAns']) ? $_SESSION['submitAns'] : [];

        //If the submit button is pressed, gather the answers for each question and store them to the session.
        //If all answers not posted - throw user the error page
        if (isset($_POST['submitButton']) && $_POST['submitButton'] === 'submitQuiz') {
            for ($i = 0; $i < count($quiz['questions']); $i++) {
                $questionNumber = 'question_' . $i;
                if (isset($_POST[$questionNumber])) {
                    $submitAns[$i] = $_POST[$questionNumber];
                }
            }
            $_SESSION['submitAns'] = $submitAns;

            header('Location: results.php');
            exit();
        }
        //Navigating back and forth - if it's pressed change teh current question and update the array of submitted answers
        if (isset($_POST['prevButton']) && $currentQuestion > 0) {
            $questionNumber = 'question_' . $currentQuestion;
            if (isset($_POST[$questionNumber])) {
                $_SESSION['submitAns'][$currentQuestion] = $_POST[$questionNumber];
            }
            $_SESSION['currentQuestion'] = $currentQuestion - 1;
            header('Location: displayQuiz.php');
            exit();
        } elseif (isset($_POST['nextButton']) && $currentQuestion < count($quiz['questions']) - 1) {
            $questionNumber = 'question_' . $currentQuestion;
            if (isset($_POST[$questionNumber])) {
                $_SESSION['submitAns'][$currentQuestion] = $_POST[$questionNumber];
            }

            $_SESSION['currentQuestion'] = $currentQuestion + 1;
            header('Location: displayQuiz.php');
            exit();
        }

        //Display the quiz and nav buttons to the user
        if (isset($quiz)) {
            echo "<h2>Selected Quiz " . $quiz['title'] . "</h2>";
            echo "<form method='post' class='quiz'>";
            echo "<div class='question-card'>";
            echo "<div class='questionNumberText'> Question " . ($currentQuestion + 1) . ": </div>";
            echo "<br>";
            echo "<div class='questionText'>" . $quiz['questions'][$currentQuestion]['questionText'];
            echo "</div>";
            //Ensures that the answer that is stored in $submitAns is re-selected on page load if it's set
            for ($j = 0; $j < count($quiz['questions'][$currentQuestion]['choices']); $j++) {
                echo "<br>";
                $choiceName = 'question_' . $currentQuestion;
                $isChecked = (isset($submitAns[$currentQuestion]) && $submitAns[$currentQuestion] == $j) ? 'checked' : '';
                echo "<input type='radio' name='$choiceName' value='$j' $isChecked >" . $quiz['questions'][$currentQuestion]['choices'][$j];
            }
            echo "</div>";
            echo "<br>";
            echo "<div class='navigation'>";

            if ($currentQuestion > 0) {
                echo "<button class='btn' name='prevButton'>Previous</button>";
            }
            if ($currentQuestion < count($quiz['questions']) - 1) {
                echo "<button class='btn' name='nextButton'>Next</button>";
            } else {
                echo "<button class='btn' type='submit' name='submitButton' value='submitQuiz'>Submit Quiz</button>";
            }

            echo "</div>";
            echo "</form>";
        }
    } else {
        echo "Hey, there is something wrong - looks like your quiz data isn't loading properly!";
    }
    ?>

</body>

</html>