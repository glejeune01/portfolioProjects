<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>Quiz Selection</title>
</head>
<body>
Please ensure the JSON data exists and you've answered all questions!
</body>
</html>