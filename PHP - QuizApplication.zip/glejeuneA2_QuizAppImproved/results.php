<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>Quiz Results</title>
</head>

<body>
    <?php
    include 'ChromePhp.php';
    include 'FileUtils.php';
    session_start();
    //gathering up the session data to be used
    $quiz = $_SESSION['myData'];
    $submitAns = $_SESSION['submitAns'];
    $selectedQuiz = $_SESSION['selectedQuiz'];
    $correctCounter = 0;

    if ($quiz !== null && $selectedQuiz !== null) {
        echo "<h2>Quiz Results for: $selectedQuiz</h2>";
        //setting up the correct answers, and setting the user answers to the submitted answer per question
        for ($i = 0; $i < count($quiz['questions']); $i++) {
            $correctAnswer = $quiz['questions'][$i]['answer'];

            if (isset($submitAns[$i])) {
                $userAnswer = $submitAns[$i];
            } else {
                header("location: error.php");
                exit();
            }

            $questionText = $quiz['questions'][$i]['questionText'];
            //Setting the class of the answer, and the user answer. Highlighting and adding leader text appropriatly 
            $correctAnswerStyling = "correct";
            $userAnswerStyling = ($userAnswer != $correctAnswer) ? "incorrect" : "";

            echo "<div class='answer-card'>";
            echo "<div class='questionNumberText'> Question " . ($i + 1) . ": </div>";
            echo "<br>";
            echo "<div class='questionText'>" . $questionText . "</div>";

            for ($j = 0; $j < count($quiz['questions'][$i]['choices']); $j++) {
                echo "<br>";
                $choiceText = $quiz['questions'][$i]['choices'][$j];
                
                if($j == $userAnswer && $j == $correctAnswer)
                {
                    $choiceClass = $correctAnswerStyling;
                    $choiceText = "Your answer is correct: " . $choiceText;
                }
                else if ($j == $correctAnswer) {
                    $choiceClass = $correctAnswerStyling;
                    $choiceText = "Correct Answer: " . $choiceText; 
                } 

                else if ($j == $userAnswer) {
                    $choiceClass = " $userAnswerStyling";
                    $choiceText = "Your Answer: " . $choiceText; 
                }

                else {
                    $choiceClass = "";
                }
                echo "<div class='$choiceClass'>$choiceText</div>";
            }

            echo "<br>";
            echo "</div>";

            if ($userAnswer == $correctAnswer) {
                $correctCounter++;
            }
        }
        //posting your # of correct answers
        echo "<h3>Congrats, you got $correctCounter out of " . count($quiz['questions']) . " correct.</h3>";
        echo "<a href = 'index.php'> <button class='btn' type='submit' name='submitButton' value='submitQuiz'>Do another quiz?</button> </a>";
    } else {
        header("location: error.php");
    }
    ?>
</body>

</html>
