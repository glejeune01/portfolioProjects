<?php
session_start();
include 'ChromePhp.php';
include 'FileUtils.php';


//After the user has set the dropdown - save the selected quiz to the session
if (isset($_POST['dropdown'])) { 
    $selectedQuiz = $_POST['dropdown']; 
    $fileContents = readFileIntoString($selectedQuiz);
    $quiz = json_decode($fileContents, true);
    $_SESSION['selectedQuiz'] = $selectedQuiz;
    $_SESSION['myData'] = $quiz;
    $_SESSION['submitAns'] = [];
    $_SESSION['currentQuestion'] = 0;
    header("location: displayQuiz.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>Quiz Selection</title>
</head>
<!-- basic HTML to show a dropdown selector of the possible quizzes -->
<body>
    <form method="post">
        <label for="dropdown">Select a Quiz:</label>
        <select id="dropdown" name="dropdown">
            <option value="NumberSystems.json">Number Systems</option>
            <option value="WorldGeography1.json">World Geography</option>
        </select>
        <button type="submit">Select Quiz</button>
    </form>
</body>

</html>