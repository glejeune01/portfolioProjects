package ferry;

/**
 * A ferry that transports vehicles and people.
 */
public class Ferry {

    private String name;
    private Passenger[] passengers;
    private Vehicle[] normalVehicles;
    private Vehicle[] largeVehicles;

    public Ferry(String name, int passengerSpaces, int normalVehicleSpaces, int largeVehicleSpaces) {

        // TODO-A1: YOUR CODE HERE
        this.name = name;
        this.passengers = new Passenger[passengerSpaces];
        this.normalVehicles = new Vehicle[normalVehicleSpaces];
        this.largeVehicles = new Vehicle[largeVehicleSpaces];
    }

    /**
     * Creates a string containing information about this ferry. The string has
     * the following form:
     *
     * ***** Status Report for Ferry ____ ***** Passengers: ____ Weight: ____
     * Normal-Size Vehicles: ____ Weight: ____ Large-Size Vehicles: ____ Weight:
     * ____ Total Weight: ____
     *
     * @return the reportStatus string
     */
    public String reportStatus() {
        // TODO-A2: YOUR CODE HERE
        int totalWeightPassengers = 0;
        int totalPassangers = 0;
        int totalNormal = 0;
        int totalLarge = 0;

        for (Passenger passenger : passengers) {
            if (passenger != null) {
                totalWeightPassengers += Constants.AVERAGE_PASSENGER_WEIGHT;
                totalPassangers++;
            }
        }

        for (Vehicle vehicle : normalVehicles) {
            if (vehicle != null) {
                totalNormal++;
            }
        }

        for (Vehicle vehicle : largeVehicles) {
            if (vehicle != null) {
                totalLarge++;
            }
        }

        int totalWeightNormal = TotalWeight(normalVehicles);
        int totalWeightLarge = TotalWeight(largeVehicles);
        int totalWeight = totalWeightPassengers + totalWeightNormal + totalWeightLarge;

        String res = "Status Report for Ferry '" + name + "'";
        res += "\n\n";
        res += "Passengers: \t\t" + totalPassangers + "\t" + "Weight: " + totalWeightPassengers + "\n";
        res += "Normal-Size Vehicles: \t" + totalNormal + "\t" + "Weight: " + totalWeightNormal + "\n";
        res += "Large-Size Vehicles: \t" + totalLarge + "\t" + "Weight: " + totalWeightLarge + "\n";
        res += "\n\t\t\tTotal Weight: \t" + totalWeight;
        return res;
    }

    public String loadPassenger(Passenger p) {
        for (int i = 0; i < passengers.length; i++) {
            if (passengers[i] == null) {
                passengers[i] = p;
                return "OK";
            }
        }
        return "Passenger spaces are full.";
    }

    public void removePassenger(Passenger p) {
        for (int i = 0; i < passengers.length; i++) {
            if (passengers[i] == p) {
                passengers[i] = null;
            }
        }
    }

public String loadVehicle(Vehicle v) {
    String vehicleType = v.getSize();

    int availablePassengerSpaces = 0;
    for (Passenger passenger : passengers) {
        if (passenger == null) {
            availablePassengerSpaces++;
        }
    }

    int availableVehicleSpaces = 0;
    Vehicle[] vehicleSpaces = (vehicleType.equals("normal")) ? normalVehicles : largeVehicles;

    for (int i = 0; i < vehicleSpaces.length; i++) {
        if (vehicleSpaces[i] == null) {
            availableVehicleSpaces++;
        }
    }

    if (availablePassengerSpaces > 0 && availableVehicleSpaces > 0) {
        for (int i = 0; i < vehicleSpaces.length; i++) {
            if (vehicleSpaces[i] == null) {
                vehicleSpaces[i] = v;
                return "OK";
            }
        }
    } else if (availableVehicleSpaces <= 0) {
        return (vehicleType.equals("normal")) ? "Normal vehicle spaces are full." : "Large vehicle spaces are full.";
    } else if (availablePassengerSpaces <= 0) {
        return "Passenger spaces are full.";
    }

    return "Invalid vehicle size.";
}


    public Passenger[] getPassengers() {
        return passengers;
    }

    public Vehicle[] getNormalVehicles() {
        return normalVehicles;
    }

    public Vehicle[] getLargeVehicles() {
        return largeVehicles;
    }

    private int TotalWeight(Object[] vehicalType) {
        int totalWeight = 0;

        for (Object vehical : vehicalType) {
            if (vehical != null) {
                totalWeight += ((Vehicle) vehical).getWeight();
            }
        }
        return totalWeight;
    }
} // end class Ferry
